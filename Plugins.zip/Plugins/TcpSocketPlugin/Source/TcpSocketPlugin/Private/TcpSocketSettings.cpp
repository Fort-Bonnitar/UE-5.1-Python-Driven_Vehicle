// SpartanTools 2019

#include "TcpSocketSettings.h"